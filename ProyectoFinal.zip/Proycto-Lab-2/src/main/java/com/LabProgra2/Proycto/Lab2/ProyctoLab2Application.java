package com.LabProgra2.Proycto.Lab2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyctoLab2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyctoLab2Application.class, args);
	}

}
